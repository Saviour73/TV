﻿namespace TVApi.Model
{
    public class TVRepository
    {
    }
}
