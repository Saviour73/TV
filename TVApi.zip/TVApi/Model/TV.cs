﻿namespace TVApi.Model
{
    public class TV
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }
        // Add other properties as needed

    }
}
